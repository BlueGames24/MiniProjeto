# Lista de filmes e anos de lançamento diretamente no código
filmes = [
    "O Poderoso Chefão (1972)",
    "Forrest Gump (1994)",
    "Matrix (1999)",
    "Titanic (1997)",
    "Clube da Luta (1999)",
    "Pulp Fiction (1994)",
    "O Senhor dos Anéis: A Sociedade do Anel (2001)",
    "Star Wars: Uma Nova Esperança (1977)",
    "O Silêncio dos Inocentes (1991)",
    "A Origem (2010)",
    "Os Bons Companheiros (1990)",
    "Beleza Americana (1999)",
    "O Cavaleiro das Trevas (2008)",
    "Jurassic Park (1993)",
    "O Iluminado (1980)",
    "De Volta para o Futuro (1985)",
    "Gladiador (2000)",
    "Indiana Jones e os Caçadores da Arca Perdida (1981)",
    "Toy Story (1995)",
    "O Grande Lebowski (1998)",
    "Django Livre (2012)",
    "Scarface (1983)",
    "A Vida é Bela (1997)",
    "Coração Valente (1995)",
    "Os Infiltrados (2006)",
    "Rocky: Um Lutador (1976)",
    "Apocalypse Now (1979)",
    "Mad Max: Estrada da Fúria (2015)",
    "A Lista de Schindler (1993)",
    "O Fabuloso Destino de Amélie Poulain (2001)",
    "Cidade de Deus (2002)",
    "Alien: O Oitavo Passageiro (1979)",
    "2001: Uma Odisseia no Espaço (1968)",
    "Um Sonho de Liberdade (1994)",
    "O Resgate do Soldado Ryan (1998)",
    "O Sexto Sentido (1999)",
    "A Princesa Prometida (1987)",
    "Harry Potter e a Pedra Filosofal (2001)",
    "Os Vingadores (2012)",
    "O Expresso da Meia-Noite (1978)",
    "A Noviça Rebelde (1965)",
    "Cisne Negro (2010)",
    "Os Caça-Fantasmas (1984)",
    "Kill Bill: Volume 1 (2003)",
    "O Homem-Aranha (2002)",
    "O Estranho Mundo de Jack (1993)",
    "Blade Runner (1982)",
    "A Bela e a Fera (1991)",
    "Laranja Mecânica (1971)",
    "E.T.: O Extraterrestre (1982)",
    "A Era do Gelo (2002)",
    "Bastardos Inglórios (2009)",
    "Pantera Negra (2018)",
    "Ratatouille (2007)",
    "O Rei Leão (1994)",
    "Piratas do Caribe: A Maldição do Pérola Negra (2003)",
    "Clube dos Cinco (1985)",
    "Vingadores: Ultimato (2019)",
    "As Branquelas (2004)",
    "Uma Linda Mulher (1990)",
    "A Forma da Água (2017)",
    "Grease: Nos Tempos da Brilhantina (1978)",
    "O Hobbit: Uma Jornada Inesperada (2012)",
    "O Pianista (2002)",
    "Doze Homens e Uma Sentença (1957)",
    "Rocky II (1979)",
    "Tubarão (1975)",
    "O Grande Hotel Budapeste (2014)",
    "Logan (2017)",
    "A Chegada (2016)",
    "Os Intocáveis (2011)",
    "A Morte lhe Cai Bem (1992)",
    "Um Lugar Chamado Notting Hill (1999)",
    "Sweeney Todd (2007)",
    "Senhor dos Anéis: As Duas Torres (2002)",
    "O Predador (1987)",
    "A Mosca (1986)",
    "O Plano Perfeito (2006)",
    "Caça aos Gângsteres (2013)",
    "Os 12 Macacos (1995)",
    "A Rede Social (2010)",
    "Os Suspeitos (1995)",
    "Halloween (1978)",
    "Duro de Matar (1988)",
    "Borat (2006)",
    "Meninas Malvadas (2004)",
    "A Rainha (2006)",
    "Batman Begins (2005)",
    "Tróia (2004)",
    "Brilho Eterno de uma Mente sem Lembranças (2004)",
    "Homem de Ferro (2008)",
    "Moulin Rouge (2001)",
    "Divergente (2014)",
    "Corra! (2017)",
    "Zootopia (2016)",
    "Até o Último Homem (2016)",
    "O Lobo de Wall Street (2013)",
    "A Grande Aposta (2015)",
    "O Escafandro e a Borboleta (2007)",
    "Os Miseráveis (2012)",
    "Super Mario Bros The movie (2023)",
    "Five Nights at Freddy's O pesadelo sem fim (2023)",
    "Divertida mente (2015)",
    "Divertida mente 2 (2024)"
]

def exibir_filmes(filmes):
    if filmes:
        print("Lista de filmes disponíveis:")
        for filme in filmes:
            print(f"- {filme}")
    else:
        print("A lista de filmes está vazia.")

def pesquisar_filme(filmes, termo):
    resultados = [filme for filme in filmes if termo.lower() in filme.lower()]
    if resultados:
        print("Resultados da pesquisa:")
        for resultado in resultados:
            print(f"- {resultado}")
    else:
        print(f"Nenhum filme encontrado com o termo '{termo}'.")

def main():
    while True:
        print("\nOpções:")
        print("1. Ver todos os filmes")
        print("2. Pesquisar um filme")
        print("3. Sair")
        opcao = input("Escolha uma opção: ")

        if opcao == '1':
            exibir_filmes(filmes)
        elif opcao == '2':
            termo = input("Digite o nome ou parte do nome do filme que deseja pesquisar: ")
            pesquisar_filme(filmes, termo)
        elif opcao == '3':
            print("Saindo do programa...")
            break
        else:
            print("Opção inválida. Tente novamente.")

if __name__ == "__main__":
    main()
